db.members.aggregate({$unwind: '$coverages'},{$group: { _id : '$_id', 'count': {$sum:1}}},{$project :{_id:1,count:1}}).forEach(function(x){print(x._id+ '\t' +x.count)}) 
