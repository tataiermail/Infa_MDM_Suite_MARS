db.students.find().forEach(function(x){print(x.name + ' , ' + x.scores[0].type + ' , ' + x.scores[0].score + ' , ' + x.scores[1].type + ' , ' + x.scores[1].score)}) 
